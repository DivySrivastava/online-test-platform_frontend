"use strict";(self.webpackChunkreact_project=self.webpackChunkreact_project||[]).push([[488],{2488(){new Map,new Date}}]);
//# sourceMappingURL=488.ae79cafe.chunk.js.map